// AutoSolve AI Content Script
// Natural Coordinate Clicker, 16x Video Speed Controller & Live Console HUD

(function () {
  if (window.__AUTOSOLVE_AI_INJECTED__) {
    console.log('[AutoSolve AI] Content script already active in this tab.');
    return;
  }
  window.__AUTOSOLVE_AI_INJECTED__ = true;

  const state = {
    currentCursorPos: { x: window.innerWidth / 2, y: window.innerHeight / 2 },
    isExecuting: false,
    virtualCursorElem: null,
    logs: [],
    watchdogTimer: null,
  };

  // Clean up any legacy on-screen HUD overlay element so no UI is rendered over web page
  try {
    const existingHud = document.getElementById('autosolve-ai-hud');
    if (existingHud) existingHud.remove();
  } catch {}

  function addLog(level, message, detail = null) {
    const timestamp = new Date().toLocaleTimeString();
    const entry = { timestamp, level, message, detail };
    state.logs.push(entry);
    if (state.logs.length > 150) state.logs.shift();

    // Broadcast strictly to background and extension console
    chrome.runtime.sendMessage({
      action: 'NEW_LOG',
      log: entry,
    }).catch(() => {});
  }

  function ensureVirtualCursor() {
    if (state.virtualCursorElem && document.body.contains(state.virtualCursorElem)) {
      return state.virtualCursorElem;
    }
    const cursor = document.createElement('div');
    cursor.id = 'autosolve-ai-cursor';
    cursor.innerHTML = `
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" style="filter: drop-shadow(0 3px 6px rgba(0,0,0,0.5));">
        <path d="M4 3L11 20L13.5 13.5L20 11L4 3Z" fill="#2563eb" stroke="#ffffff" stroke-width="1.8"/>
        <circle cx="4" cy="3" r="2.5" fill="#60a5fa" />
      </svg>
    `;
    Object.assign(cursor.style, {
      position: 'fixed',
      top: '0px',
      left: '0px',
      pointerEvents: 'none',
      zIndex: '2147483647',
      transform: `translate(${state.currentCursorPos.x}px, ${state.currentCursorPos.y}px)`,
      transition: 'opacity 0.2s ease',
      willChange: 'transform',
    });
    document.body.appendChild(cursor);
    state.virtualCursorElem = cursor;
    return cursor;
  }

  function cubicBezier(t, p0, p1, p2, p3) {
    const mt = 1 - t;
    return mt * mt * mt * p0 + 3 * mt * mt * t * p1 + 3 * mt * t * t * p2 + t * t * t * p3;
  }

  async function moveCursorNaturally(targetX, targetY, durationMs = 450) {
    if (isNaN(targetX) || isNaN(targetY)) {
      console.warn('[AutoSolve AI] moveCursorNaturally called with invalid coords:', { targetX, targetY });
      return;
    }

    const cursor = ensureVirtualCursor();
    const startX = state.currentCursorPos.x;
    const startY = state.currentCursorPos.y;
    const dx = targetX - startX;
    const dy = targetY - startY;
    const distance = Math.hypot(dx, dy);

    // Natural curved human trajectory with slight curvature deviation
    const deviation = (Math.random() - 0.5) * Math.min(distance * 0.3, 75);
    const p1x = startX + dx * 0.25 - deviation * 0.5;
    const p1y = startY + dy * 0.25 + deviation;
    const p2x = startX + dx * 0.75 + deviation * 0.3;
    const p2y = startY + dy * 0.75 - deviation * 0.5;

    const steps = Math.max(16, Math.floor(durationMs / 16));
    const stepDuration = durationMs / steps;

    for (let i = 0; i <= steps; i++) {
      const rawT = i / steps;
      // Smooth easeInOut
      const t = rawT < 0.5 ? 2 * rawT * rawT : -1 + (4 - 2 * rawT) * rawT;
      let curX = cubicBezier(t, startX, p1x, p2x, targetX);
      let curY = cubicBezier(t, startY, p1y, p2y, targetY);

      // Micro human hand tremor
      if (i > 0 && i < steps) {
        curX += (Math.random() - 0.5) * 1.5;
        curY += (Math.random() - 0.5) * 1.5;
      }

      cursor.style.transform = `translate(${curX}px, ${curY}px)`;
      state.currentCursorPos = { x: curX, y: curY };
      await new Promise((r) => setTimeout(r, stepDuration));
    }
  }

  function flashClickEffect(x, y) {
    try {
      const ring = document.createElement('div');
      Object.assign(ring.style, {
        position: 'fixed',
        left: `${x - 18}px`,
        top: `${y - 18}px`,
        width: '36px',
        height: '36px',
        borderRadius: '50%',
        border: '2px solid #2563eb',
        backgroundColor: 'rgba(37, 99, 235, 0.25)',
        pointerEvents: 'none',
        zIndex: '2147483647',
        animation: 'autosolve-pulse 0.4s ease-out forwards',
      });
      document.body.appendChild(ring);
      setTimeout(() => ring.remove(), 450);
    } catch {}
  }

  // Traverse all documents (top level window, Edgenuity #stageFrame, and nested activity iframes)
  function getAllDocuments() {
    const docs = [document];
    try {
      const frames = document.querySelectorAll('iframe, frame');
      for (const f of frames) {
        try {
          const d = f.contentDocument || f.contentWindow?.document;
          if (d && !docs.includes(d)) {
            docs.push(d);
            const subFrames = d.querySelectorAll('iframe, frame');
            for (const sf of subFrames) {
              try {
                const sd = sf.contentDocument || sf.contentWindow?.document;
                if (sd && !docs.includes(sd)) docs.push(sd);
              } catch {}
            }
          }
        } catch {}
      }
    } catch {}
    return docs;
  }

  // Find interactable element penetrating through iframes (adjusting relative coordinates at each level)
  function resolveInteractiveElement(x, y) {
    let curDoc = document;
    let curX = x;
    let curY = y;
    let targetEl = null;

    for (let depth = 0; depth < 5; depth++) {
      const el = curDoc.elementFromPoint(curX, curY);
      if (!el) break;
      targetEl = el;

      if (el.tagName === 'IFRAME' || el.tagName === 'FRAME') {
        try {
          const rect = el.getBoundingClientRect();
          const subDoc = el.contentDocument || el.contentWindow?.document;
          if (subDoc) {
            curDoc = subDoc;
            curX = curX - rect.left;
            curY = curY - rect.top;
            continue;
          }
        } catch (e) {
          break;
        }
      }
      break;
    }

    if (!targetEl) return null;

    const doc = targetEl.ownerDocument || document;

    // Check if directly clickable or input
    if (
      targetEl.tagName === 'INPUT' ||
      targetEl.tagName === 'BUTTON' ||
      targetEl.tagName === 'LABEL' ||
      targetEl.getAttribute('role') === 'radio' ||
      targetEl.getAttribute('role') === 'checkbox' ||
      targetEl.getAttribute('role') === 'button'
    ) {
      return { element: targetEl, clientX: curX, clientY: curY, doc };
    }

    // Look upwards in the DOM hierarchy (handles answer choices, nav buttons, li.choice, FrameRight)
    const ancestor = targetEl.closest(
      'button, label, input, [role="radio"], [role="checkbox"], [role="button"], a, li, .answer-choice, .answer-choice-button, .mc-choice, .FrameRight, .FrameLeft, .footernav, .btnCheck, .btnNext'
    );
    if (ancestor) return { element: ancestor, clientX: curX, clientY: curY, doc };

    // Search inside the target element for input, button, or label
    const child = targetEl.querySelector('input, button, [role="radio"], [role="checkbox"], a, .answer-choice, label');
    if (child) return { element: child, clientX: curX, clientY: curY, doc };

    return { element: targetEl, clientX: curX, clientY: curY, doc };
  }

  // Complete realistic human click sequence dispatch (satisfies W3C, jQuery, Angular, React, and Edgenuity event listeners)
  async function dispatchRealisticClick(targetEl, localX, localY) {
    if (!targetEl) return false;
    const doc = targetEl.ownerDocument || document;
    const win = doc.defaultView || window;

    const rect = targetEl.getBoundingClientRect();
    const clickX = typeof localX === 'number' ? localX : (rect.left + rect.width / 2);
    const clickY = typeof localY === 'number' ? localY : (rect.top + rect.height / 2);

    const eventInitCommon = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: win,
      clientX: clickX,
      clientY: clickY,
      screenX: (win.screenX || 0) + clickX,
      screenY: (win.screenY || 0) + clickY,
    };

    const pointerDownInit = {
      ...eventInitCommon,
      button: 0,
      buttons: 1, // MANDATORY for browser and framework hit-test!
      isPrimary: true,
      pointerId: 1,
      pointerType: 'mouse',
      pressure: 0.5,
    };

    const pointerUpInit = {
      ...eventInitCommon,
      button: 0,
      buttons: 0,
      isPrimary: true,
      pointerId: 1,
      pointerType: 'mouse',
      pressure: 0,
    };

    const mouseDownInit = {
      ...eventInitCommon,
      button: 0,
      buttons: 1, // MANDATORY for Chromium / Edge!
    };

    const mouseUpInit = {
      ...eventInitCommon,
      button: 0,
      buttons: 0,
    };

    // 1. Mouse and Pointer Enter & Hover
    targetEl.dispatchEvent(new PointerEvent('pointerover', pointerDownInit));
    targetEl.dispatchEvent(new MouseEvent('mouseover', mouseDownInit));
    targetEl.dispatchEvent(new PointerEvent('pointerenter', pointerDownInit));
    targetEl.dispatchEvent(new MouseEvent('mouseenter', mouseDownInit));

    // 2. Focus element if focusable
    if (typeof targetEl.focus === 'function') {
      try { targetEl.focus(); } catch {}
    }

    // 3. PointerDown & MouseDown with buttons: 1
    targetEl.dispatchEvent(new PointerEvent('pointerdown', pointerDownInit));
    targetEl.dispatchEvent(new MouseEvent('mousedown', mouseDownInit));

    await new Promise((r) => setTimeout(r, 45 + Math.random() * 30));

    // 4. PointerUp & MouseUp with buttons: 0
    targetEl.dispatchEvent(new PointerEvent('pointerup', pointerUpInit));
    targetEl.dispatchEvent(new MouseEvent('mouseup', mouseUpInit));

    // 5. Click event
    targetEl.dispatchEvent(new MouseEvent('click', mouseUpInit));

    // 6. Direct DOM element.click()
    if (typeof targetEl.click === 'function') {
      try { targetEl.click(); } catch {}
    }

    // 7. Find associated radio / checkbox input in this frame
    let input = targetEl.tagName === 'INPUT' ? targetEl : targetEl.querySelector('input[type="radio"], input[type="checkbox"]');
    if (!input && targetEl.tagName === 'LABEL' && targetEl.htmlFor) {
      input = doc.getElementById(targetEl.htmlFor);
    }
    if (!input) {
      const parentChoice = targetEl.closest('.answer-choice, .answer-choice-button, li, [role="radio"]');
      if (parentChoice) {
        input = parentChoice.querySelector('input[type="radio"], input[type="checkbox"]');
      }
    }

    if (input) {
      input.checked = true;
      input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
      try { input.click(); } catch {}
    }

    // 8. Find associated label in this frame
    const label = targetEl.tagName === 'LABEL' ? targetEl : (input?.id ? doc.querySelector(`label[for="${input.id}"]`) : targetEl.closest('label'));
    if (label && label !== targetEl) {
      try { label.click(); } catch {}
    }

    // 9. If element is an anchor or inside an anchor (e.g. Edgenuity li.footernav.navnext a or .FrameRight)
    const anchor = targetEl.tagName === 'A' ? targetEl : targetEl.closest('a');
    if (anchor && anchor !== targetEl) {
      try { anchor.click(); } catch {}
      if (anchor.href && anchor.href.startsWith('javascript:')) {
        try { win.eval(anchor.href.replace(/^javascript:/, '')); } catch {}
      }
    }

    // 10. Direct jQuery trigger if jQuery is present in this window context (Edgenuity uses jQuery in stageFrame)
    if (win && (win.jQuery || win.$)) {
      try {
        const jq = win.jQuery || win.$;
        jq(targetEl).trigger('click');
        if (input) jq(input).prop('checked', true).trigger('change').trigger('click');
        if (anchor) jq(anchor).trigger('click');
      } catch {}
    }

    return true;
  }

  async function simulateClick(x, y, label = '') {
    if (isNaN(x) || isNaN(y)) {
      console.warn('[AutoSolve AI] simulateClick called with NaN coordinates');
      return false;
    }

    flashClickEffect(x, y);

    // 1. Primary Strategy: Native Hardware Click via Chrome DevTools Protocol (CDP Debugger with buttons: 1)
    let nativeClicked = false;
    try {
      const cdpRes = await chrome.runtime.sendMessage({
        action: 'PERFORM_NATIVE_CLICK',
        x,
        y,
        label,
      });
      nativeClicked = !!cdpRes?.success;
    } catch (e) {
      console.warn('[AutoSolve AI] Background CDP click bridge unavailable:', e);
    }

    // 2. Secondary Strategy: Deep Frame Penetrating Realistic DOM Dispatch
    const resolved = resolveInteractiveElement(x, y);
    const targetEl = resolved?.element;
    const elemName = targetEl ? targetEl.tagName.toLowerCase() : 'unknown';
    const textSnippet = targetEl ? (targetEl.innerText || targetEl.textContent || '').trim().slice(0, 35) : '';

    // MANDATORY REQUIREMENT: Note every click in the console with exact coordinates!
    console.log(
      `%c[AutoSolve AI][CLICK] Clicked at coordinate (X: ${Math.round(x)}px, Y: ${Math.round(y)}px)${label ? ` for [${label}]` : ''} on <${elemName}> "${textSnippet}" [CDP isTrusted: ${nativeClicked ? 'true' : 'synthetic'}]`,
      'color: #059669; font-weight: bold; background: #ecfdf5; padding: 2px 6px; border-radius: 4px;'
    );
    addLog('CLICK', `Clicked (X: ${Math.round(x)}px, Y: ${Math.round(y)}px)${label ? ` [${label}]` : ''} ${nativeClicked ? '(Hardware isTrusted: true)' : ''}`);

    if (targetEl) {
      await dispatchRealisticClick(targetEl, resolved.clientX, resolved.clientY);
      return true;
    }

    return nativeClicked;
  }

  // Edgenuity & LMS Option Selector: Directly matches radio buttons and choices across all frames
  async function selectAnswerChoice(opt, index) {
    const docs = getAllDocuments();
    const cleanTargetText = (opt?.text || '').trim().toLowerCase();

    console.log(`[AutoSolve AI][ANSWER] Selecting choice ${index + 1} ("${opt?.text}") across all frames...`);

    for (const doc of docs) {
      // 1. Match radio or checkbox by index
      const radios = Array.from(doc.querySelectorAll('input[type="radio"], input[type="checkbox"]'));
      if (radios.length > index && radios.length <= 12) {
        const radio = radios[index];
        console.log(`[AutoSolve AI][ANSWER] Found radio input at index ${index} in frame:`, radio);
        await dispatchRealisticClick(radio);
        return true;
      }

      // 2. Match Edgenuity choice container (.answer-choice, .answer-choice-button, .mc-choice, li.choice)
      const choiceContainers = Array.from(doc.querySelectorAll('.answer-choice, .answer-choice-button, .mc-choice, li.choice, .choice-container, div[data-choice]'));
      if (choiceContainers.length > index && choiceContainers.length <= 12) {
        const choice = choiceContainers[index];
        console.log(`[AutoSolve AI][ANSWER] Found choice container at index ${index} in frame:`, choice);
        await dispatchRealisticClick(choice);
        return true;
      }

      // 3. Text match on label, span, div, li
      if (cleanTargetText && cleanTargetText.length > 1) {
        const candidates = Array.from(doc.querySelectorAll('label, .answer-choice, li, div.text, span.text, p'));
        for (const el of candidates) {
          const txt = (el.innerText || '').trim().toLowerCase();
          if (txt === cleanTargetText || (txt.length < 200 && txt.includes(cleanTargetText))) {
            console.log(`[AutoSolve AI][ANSWER] Found text-matched option in frame:`, el);
            await dispatchRealisticClick(el);
            return true;
          }
        }
      }
    }

    return false;
  }

  // Edgenuity & LMS Next Button Advance: Targets .FrameRight, .navnext, .navsave, #btnCheck, #btnNext
  async function advanceNextButton() {
    console.log('[AutoSolve AI][NEXT] Searching for Next/Submit buttons across all frames...');
    const docs = getAllDocuments();

    // Priority 1: Edgenuity-specific selectors
    const edgenuitySelectors = [
      '.FrameRight',
      '.footernav.navnext a',
      'a.footernav.navnext',
      'li.footernav.navnext a',
      '.footernav.navnext',
      'li.footernav.navnext',
      '.footernav.navsave a',
      'a.footernav.navsave',
      'li.footernav.navsave a',
      '#btnCheck',
      '#btnNext',
      'input#btnCheck',
      'input#btnNext',
      '.btnCheck',
      '.btnNext',
      '.stage-footer .navnext',
      '.stage-footer .navsave',
      '.uilib-btn-next',
      '.uilib-btn-primary',
      'button.uilib-btn-primary',
      '.invis-next',
      'a[title*="Next" i]',
      'button[title*="Next" i]',
      'input[value*="Next" i]',
      'input[value*="Submit" i]',
      'input[value*="Check" i]'
    ];

    for (const doc of docs) {
      for (const sel of edgenuitySelectors) {
        const el = doc.querySelector(sel);
        if (el && el.offsetParent !== null) { // visible in layout
          console.log(`[AutoSolve AI][NEXT] Found Edgenuity Next button with selector "${sel}" in frame:`, el);
          await dispatchRealisticClick(el);
          return true;
        }
      }
    }

    // Priority 2: General text-matched buttons across all frames
    for (const doc of docs) {
      const buttons = Array.from(doc.querySelectorAll('button, input[type="button"], input[type="submit"], a, [role="button"], div.button'));
      const matched = buttons.find((el) => {
        const text = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase().trim();
        return /^(next|continue|submit|finish|proceed|advance|check|check answer)$/i.test(text) ||
               /next|continue|submit/i.test(text);
      });
      if (matched && matched.offsetParent !== null) {
        console.log('[AutoSolve AI][NEXT] Found text-matched Next button in frame:', matched);
        await dispatchRealisticClick(matched);
        return true;
      }
    }

    return false;
  }

  async function accelerateVideos(speed = 16.0, triggerNext = true, nextCoords = null) {
    const docs = getAllDocuments();
    const videos = docs.flatMap((d) => Array.from(d.querySelectorAll('video')));

    if (!videos.length) {
      addLog('VIDEO', 'No HTML5 video element detected across any frames');
      return false;
    }

    videos.forEach((v) => {
      v.playbackRate = speed;
      if (v.paused) v.play().catch(() => {});
    });

    console.log(`%c[AutoSolve AI][VIDEO] Accelerated ${videos.length} video(s) across all frames to ${speed}x!`, 'color: #9333ea; font-weight: bold;');
    addLog('VIDEO', `Accelerated ${videos.length} video(s) to ${speed}x!`);

    if (triggerNext) {
      let remaining = 15;
      const interval = setInterval(async () => {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(interval);
          addLog('VIDEO', '15s video timer elapsed: Advancing to next activity...');
          if (nextCoords && typeof nextCoords.xPercent === 'number') {
            const nx = (nextCoords.xPercent / 100) * window.innerWidth;
            const ny = (nextCoords.yPercent / 100) * window.innerHeight;
            await moveCursorNaturally(nx, ny, 500);
            await simulateClick(nx, ny, 'Next Button');
          }
          await advanceNextButton();
        }
      }, 1000);
    }
    return true;
  }

  async function executeSolution(analysis, options = {}) {
    if (state.isExecuting) {
      console.warn('[AutoSolve AI] Execution already in progress. Ignoring duplicate trigger to avoid stall.');
      return { success: false, reason: 'Already executing' };
    }

    state.isExecuting = true;

    // Safety watchdog timer: force-clears state.isExecuting if anything ever hangs
    if (state.watchdogTimer) clearTimeout(state.watchdogTimer);
    state.watchdogTimer = setTimeout(() => {
      if (state.isExecuting) {
        console.warn('[AutoSolve AI] Safety Watchdog: Resetting execution lock after 12s timeout.');
        state.isExecuting = false;
      }
    }, 12000);

    let clicksPerformed = 0;

    try {
      // 1. Check for video modules
      if (analysis.hasVideo) {
        await accelerateVideos(16.0, true, analysis.nextButton?.coordinates);
        state.isExecuting = false;
        clearTimeout(state.watchdogTimer);
        return { success: true, mode: 'video', clicksPerformed: 0 };
      }

      const allOptions = analysis.options || [];

      // MANDATORY REQUIREMENT: Note retrieved answers and their X and Y coordinates in the console!
      console.group('%c[AutoSolve AI] Retrieved Answers and Coordinates from Gemini', 'color: #2563eb; font-weight: bold; font-size: 13px;');
      console.log(`Question: "${analysis.question || 'N/A'}" (Type: ${analysis.questionType || 'unknown'})`);
      console.log(`Reasoning: ${analysis.conciseReasoning || 'N/A'}`);

      allOptions.forEach((opt, idx) => {
        const isCorrect = !!opt.isCorrect;
        const xPct = typeof opt.coordinates?.xPercent === 'number' ? opt.coordinates.xPercent : (opt.coordinates?.x ?? 50);
        const yPct = typeof opt.coordinates?.yPercent === 'number' ? opt.coordinates.yPercent : (opt.coordinates?.y ?? 50);
        const xPx = Math.round((xPct / 100) * window.innerWidth);
        const yPx = Math.round((yPct / 100) * window.innerHeight);

        const badge = isCorrect ? '✓ [CORRECT ANSWER]' : '✗ [INCORRECT]';
        const color = isCorrect ? 'color: #16a34a; font-weight: bold;' : 'color: #64748b;';

        console.log(
          `%c${badge} Option ${idx + 1}: "${opt.text}" -> Coordinates: X=${xPx}px (${xPct.toFixed(1)}%), Y=${yPx}px (${yPct.toFixed(1)}%)`,
          color
        );

        if (isCorrect) {
          addLog('COORDINATES', `Retrieved answer "${opt.text}" at X=${xPx}px (${xPct.toFixed(1)}%), Y=${yPx}px (${yPct.toFixed(1)}%)`);
        }
      });

      if (analysis.nextButton?.detected || analysis.nextButton?.coordinates) {
        const nxPct = analysis.nextButton.coordinates?.xPercent ?? 88;
        const nyPct = analysis.nextButton.coordinates?.yPercent ?? 88;
        const nxPx = Math.round((nxPct / 100) * window.innerWidth);
        const nyPx = Math.round((nyPct / 100) * window.innerHeight);

        console.log(
          `%c[AutoSolve AI][COORDINATES] Next/Submit Button -> X=${nxPx}px (${nxPct.toFixed(1)}%), Y=${nyPx}px (${nyPct.toFixed(1)}%)`,
          'color: #0284c7; font-weight: bold;'
        );
        addLog('COORDINATES', `Next Button at X=${nxPx}px (${nxPct.toFixed(1)}%), Y=${nyPx}px (${nyPct.toFixed(1)}%)`);
      }
      console.groupEnd();

      // 2. Identify correct options
      let correctOptions = allOptions.filter((o) => o.isCorrect);

      // Fail-safe: if no option was marked correct, pick highest confidence option
      if (correctOptions.length === 0 && allOptions.length > 0) {
        console.warn('[AutoSolve AI] No option explicitly marked isCorrect: true. Selecting top confidence option as fallback.');
        const sorted = [...allOptions].sort((a, b) => (b.confidence || 0) - (a.confidence || 0));
        correctOptions = [sorted[0]];
      }

      // 3. Click each correct option
      for (let i = 0; i < correctOptions.length; i++) {
        const opt = correctOptions[i];
        let xPct = opt.coordinates?.xPercent;
        let yPct = opt.coordinates?.yPercent;

        // Fallbacks for coordinate format variations
        if (typeof xPct !== 'number' && typeof opt.coordinates?.x === 'number') xPct = opt.coordinates.x;
        if (typeof yPct !== 'number' && typeof opt.coordinates?.y === 'number') yPct = opt.coordinates.y;

        // Default safety
        if (typeof xPct !== 'number') xPct = 50;
        if (typeof yPct !== 'number') yPct = 50;

        const targetX = (xPct / 100) * window.innerWidth;
        const targetY = (yPct / 100) * window.innerHeight;

        await moveCursorNaturally(targetX, targetY, 450 + Math.random() * 300);
        await new Promise((r) => setTimeout(r, 100 + Math.random() * 80));

        const clicked = await simulateClick(targetX, targetY, `Answer: ${opt.text}`);
        clicksPerformed++;

        // Also explicitly guarantee Edgenuity answer selection across frames
        await selectAnswerChoice(opt, i);

        if (i < correctOptions.length - 1) {
          await new Promise((r) => setTimeout(r, 350 + Math.random() * 250));
        }
      }

      // 4. Auto-Click Next / Submit if enabled
      if (options.autoClickNext !== false) {
        await new Promise((r) => setTimeout(r, 600 + Math.random() * 300));

        let nextClicked = false;
        if (analysis.nextButton?.coordinates && typeof analysis.nextButton.coordinates.xPercent === 'number') {
          const nx = (analysis.nextButton.coordinates.xPercent / 100) * window.innerWidth;
          const ny = (analysis.nextButton.coordinates.yPercent / 100) * window.innerHeight;
          await moveCursorNaturally(nx, ny, 500);
          nextClicked = await simulateClick(nx, ny, 'Next / Submit Button');
          if (nextClicked) clicksPerformed++;
        }

        // Always attempt Edgenuity Next advance (.FrameRight, .navnext, .navsave, #btnCheck)
        const advanced = await advanceNextButton();
        if (advanced && !nextClicked) clicksPerformed++;
      }

      return { success: true, clicksPerformed };
    } catch (err) {
      console.error('[AutoSolve AI] executeSolution encountered an error:', err);
      addLog('ERROR', `Execution error: ${err.message}`);
      return { success: false, error: err.message };
    } finally {
      if (state.watchdogTimer) clearTimeout(state.watchdogTimer);
      state.isExecuting = false;
    }
  }

  // Inject styles for animations
  try {
    const styleEl = document.createElement('style');
    styleEl.textContent = `
      @keyframes autosolve-pulse {
        0% { transform: scale(0.4); opacity: 1; }
        100% { transform: scale(1.6); opacity: 0; }
      }
    `;
    document.head?.appendChild(styleEl);
  } catch {}

  // Message listener - responds asynchronously to ensure background waits!
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'EXECUTE_SOLUTION') {
      executeSolution(request.analysis, request.options)
        .then((result) => sendResponse({ success: true, ...result }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true; // Keep message channel open for async response
    } else if (request.action === 'BOOST_VIDEO_16X') {
      accelerateVideos(16.0, true)
        .then((res) => sendResponse({ success: true, count: res }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    } else if (request.action === 'TRIGGER_MANUAL_NEXT') {
      advanceNextButton().then((clicked) => {
        sendResponse({ success: clicked });
      });
      return true;
    } else if (request.action === 'PING') {
      sendResponse({ status: 'alive', injected: true });
      return true;
    }
  });

  console.log('%c[AutoSolve AI] Content Script Loaded & Ready.', 'color: #3b82f6; font-weight: bold;');
})();