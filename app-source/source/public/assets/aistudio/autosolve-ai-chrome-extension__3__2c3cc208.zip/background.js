// AutoSolve AI Background Service Worker (Manifest V3)
// Direct Gemini Vision API & Autonomous Question Solver

const DEFAULT_SERVER_URL = 'https://ais-dev-bhivux6smdwnhrhbmoqvfc-726613400165.us-west2.run.app';

function logEvent(level, message, data = null) {
  const logItem = {
    timestamp: new Date().toLocaleTimeString(),
    level,
    message,
    data,
  };
  console.log(`[AutoSolve AI][${level}] ${message}`, data || '');

  chrome.runtime.sendMessage({ action: 'NEW_LOG', log: logItem }).catch(() => {});

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'NEW_LOG', log: logItem }).catch(() => {});
    }
  });
}

async function getGeminiApiKey() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['geminiApiKey'], (result) => {
      resolve(result.geminiApiKey || '');
    });
  });
}

async function getServerUrl() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['serverUrl'], (result) => {
      resolve(result.serverUrl || DEFAULT_SERVER_URL);
    });
  });
}

let isAutoPilotRunning = false;

async function runAutonomousLoop() {
  logEvent('ACTION', '🚀 Auto-Pilot loop started.');
  while (isAutoPilotRunning) {
    logEvent('ACTION', '📸 [Auto-Pilot] Capturing tab and querying Gemini...');
    const result = await handleCaptureAndSolve({ autoClickNext: true });

    if (!isAutoPilotRunning) break;

    if (!result || !result.success) {
      logEvent('ACTION', '[Auto-Pilot] Screen check yielded no active question or action complete. Waiting 3s...');
      await new Promise((r) => setTimeout(r, 3000));
      continue;
    }

    // Wait for the next question to transition after submission
    const pauseTime = 2500 + Math.random() * 1000;
    logEvent('ACTION', `[Auto-Pilot] Question solved. Pausing ${Math.round(pauseTime)}ms for page transition...`);
    await new Promise((r) => setTimeout(r, pauseTime));
  }
}

// Ensure content script is injected into tab and all nested iframes (Edgenuity stageFrame)
async function ensureContentScriptInjected(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { action: 'PING' });
    if (ping?.status === 'alive') return true;
  } catch (e) {
    // Content script not present, inject now into ALL frames!
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ['content.js'],
      });
      await new Promise((r) => setTimeout(r, 150));
      return true;
    } catch (injectError) {
      console.warn('[AutoSolve AI] Could not inject content script:', injectError);
      return false;
    }
  }
  return true;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'START_AUTOPILOT') {
    if (!isAutoPilotRunning) {
      isAutoPilotRunning = true;
      logEvent('ACTION', '🚀 Auto-Pilot Activated! Running continuously across all questions and videos.');
      runAutonomousLoop();
    }
    sendResponse({ status: 'running' });
    return true;
  }

  if (request.action === 'STOP_AUTOPILOT') {
    isAutoPilotRunning = false;
    logEvent('ACTION', '🛑 Auto-Pilot stopped by user command.');
    sendResponse({ status: 'stopped' });
    return true;
  }

  if (request.action === 'TRIGGER_SCAN') {
    handleCaptureAndSolve(request.options).then(sendResponse);
    return true;
  }

  if (request.action === 'PERFORM_NATIVE_CLICK') {
    const directTabId = sender.tab?.id || request.tabId;
    if (directTabId) {
      performNativeClick(directTabId, request.x, request.y, request.label).then((success) => {
        sendResponse({ success });
      });
      return true;
    }
    // Query active tab fallback
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeId = tabs[0]?.id;
      if (activeId) {
        performNativeClick(activeId, request.x, request.y, request.label).then((success) => {
          sendResponse({ success });
        });
      } else {
        sendResponse({ success: false, error: 'No active tab found' });
      }
    });
    return true;
  }

  if (request.action === 'GET_STATUS') {
    getGeminiApiKey().then((apiKey) => {
      getServerUrl().then((serverUrl) => {
        sendResponse({
          status: 'active',
          hasApiKey: !!apiKey,
          serverUrl,
          isAutoPilotRunning,
        });
      });
    });
    return true;
  }
});

// Native Hardware Click via Chrome DevTools Protocol (CDP)
// Bypasses synthetic event blockers and generates real isTrusted: true clicks!
// Works seamlessly in Microsoft Edge, Google Chrome, cross-origin iframes (Edgenuity), and video players.
async function performNativeClick(tabId, x, y, label = '') {
  const target = { tabId };
  try {
    try {
      await chrome.debugger.attach(target, '1.3');
    } catch (attachErr) {
      if (!attachErr.message?.includes('Already attached')) {
        try {
          await chrome.debugger.attach(target, '1.2');
        } catch (fallbackErr) {
          if (!fallbackErr.message?.includes('Already attached')) {
            throw fallbackErr;
          }
        }
      }
    }

    const roundX = Math.round(x);
    const roundY = Math.round(y);

    // 1. Move native pointer to coordinate
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x: roundX,
      y: roundY,
      buttons: 0,
    });
    await new Promise((r) => setTimeout(r, 40));

    // 2. Mouse pressed (native isTrusted: true) - buttons: 1 MANDATORY FOR CHROMIUM/EDGE!
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x: roundX,
      y: roundY,
      button: 'left',
      buttons: 1,
      clickCount: 1,
    });
    await new Promise((r) => setTimeout(r, 80));

    // 3. Mouse released (native isTrusted: true) - buttons: 0
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x: roundX,
      y: roundY,
      button: 'left',
      buttons: 0,
      clickCount: 1,
    });

    logEvent('CLICK', `[Native CDP Click] Dispatched hardware click at (X: ${roundX}px, Y: ${roundY}px)${label ? ` for [${label}]` : ''} (buttons: 1, isTrusted: true)`);
    return true;
  } catch (err) {
    console.warn('[AutoSolve AI] Debugger click warning:', err.message);
    logEvent('ERROR', `Native debugger click note: ${err.message}.`);
    return false;
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command === 'trigger_autosolve') {
    logEvent('ACTION', 'Shortcut Alt+Shift+S detected: Initiating Auto-Solve...');
    handleCaptureAndSolve({ autoClickNext: true });
  } else if (command === 'boost_video') {
    logEvent('VIDEO', 'Shortcut Alt+Shift+V detected: Accelerating video to 16x...');
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'BOOST_VIDEO_16X' });
      }
    });
  }
});

// Direct Gemini Vision API Request Handler
async function queryGeminiDirectly(base64Image, apiKey, prompt = '') {
  const cleanBase64 = base64Image.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');

  const systemInstruction = `You are AutoSolve AI, a high-precision computer vision screen solver.
Examine this browser viewport screenshot of an educational assessment/quiz or lecture.
1. Determine if this page contains an active question or video lecture.
2. Return strictly valid JSON with this structure:
{
  "question": "string (the exact question text)",
  "questionType": "single_choice" | "multiple_choice" | "true_false" | "text" | "video_only",
  "conciseReasoning": "string (brief justification of why the answer is correct)",
  "hasVideo": boolean,
  "options": [
    {
      "text": "string (text label of option)",
      "isCorrect": boolean (true if correct answer),
      "confidence": number (0.0 to 1.0),
      "coordinates": {
        "xPercent": number (0 to 100 percentage from left of screen to clickable radio/checkbox),
        "yPercent": number (0 to 100 percentage from top of screen to clickable radio/checkbox)
      }
    }
  ],
  "nextButton": {
    "detected": boolean,
    "coordinates": {
      "xPercent": number (0 to 100 percentage from left of screen),
      "yPercent": number (0 to 100 percentage from top of screen)
    }
  }
}
ACCURACY RULE:
- Coordinates MUST be percentages from 0.0 to 100.0 pointing directly to the clickable interactive radio button, checkbox, or button center.
- Mark all correct answers with isCorrect: true.`;

  const requestBody = {
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png',
              data: cleanBase64,
            },
          },
          {
            text: prompt || 'Analyze this screen. Detect the question, choices with exact clickable coordinates (xPercent, yPercent), identify the correct answer(s), and locate the Next/Submit button.',
          },
        ],
      },
    ],
    systemInstruction: {
      parts: [{ text: systemInstruction }],
    },
    generationConfig: {
      responseMimeType: 'application/json',
      temperature: 0.1,
    },
  };

  // Try gemini-3.1-flash-lite first (highest throughput, lowest latency), fallback to gemini-3.8-flash
  const models = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
  let lastError = null;

  for (const model of models) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!rawText) throw new Error('Gemini returned an empty candidate response.');

      return JSON.parse(rawText);
    } catch (err) {
      lastError = err;
      console.warn(`[AutoSolve AI] Model ${model} failed, checking next model...`, err.message);
    }
  }

  throw lastError || new Error('All Gemini models failed to process screenshot.');
}

async function handleCaptureAndSolve(options = {}) {
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!activeTab || !activeTab.id) {
      throw new Error('No active browser tab found to capture.');
    }

    if (activeTab.url?.startsWith('chrome://') || activeTab.url?.startsWith('edge://')) {
      throw new Error('Cannot run extensions on internal browser pages (chrome://). Please navigate to your quiz or learning tab.');
    }

    // Make sure content script is active
    await ensureContentScriptInjected(activeTab.id);

    logEvent('CAPTURE', `Capturing visible tab: ${activeTab.title || 'Active Tab'}`);
    const dataUrl = await chrome.tabs.captureVisibleTab(activeTab.windowId, { format: 'png' });
    logEvent('CAPTURE', `Screenshot captured (${Math.round(dataUrl.length / 1024)} KB)`);

    const apiKey = await getGeminiApiKey();
    let analysis = null;

    if (apiKey) {
      // 1. Direct Mode: User pasted Gemini API key into popup!
      logEvent('AI_VISION', 'Querying Gemini Vision API directly with your saved API key...');
      analysis = await queryGeminiDirectly(dataUrl, apiKey, options.prompt);
    } else {
      // 2. Server Proxy Fallback: If user has a backend URL configured
      const serverUrl = await getServerUrl();
      logEvent('AI_VISION', `No API key saved in popup. Querying backend at ${serverUrl}/api/analyze-screen...`);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 20000);

      const response = await fetch(`${serverUrl}/api/analyze-screen`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: dataUrl,
          viewportWidth: activeTab.width || 1280,
          viewportHeight: activeTab.height || 720,
          userPrompt: options.prompt || '',
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Server returned ${response.status}: ${errText.slice(0, 100)}`);
      }

      const result = await response.json();
      if (!result.success || !result.analysis) {
        throw new Error(result.error || 'Server did not return a valid analysis.');
      }
      analysis = result.analysis;
    }

    if (!analysis) {
      throw new Error('Could not obtain question analysis.');
    }

    logEvent('AI_VISION', `Question detected: "${analysis.question || 'N/A'}" (Type: ${analysis.questionType})`);
    logEvent('REASONING', `Gemini Reasoning: ${analysis.conciseReasoning}`);

    // MANDATORY REQUIREMENT: Note retrieved coordinates in console!
    const opts = analysis.options || [];
    opts.forEach((o, i) => {
      const isAns = !!o.isCorrect;
      const xPct = o.coordinates?.xPercent ?? 50;
      const yPct = o.coordinates?.yPercent ?? 50;
      console.log(
        `[AutoSolve AI][COORDINATES] Option ${i + 1} [${isAns ? 'CORRECT' : 'INCORRECT'}]: "${o.text}" -> X=${xPct}%, Y=${yPct}%`
      );
      if (isAns) {
        logEvent('COORDINATES', `Answer "${o.text}" at coordinate (${xPct}%, ${yPct}%)`);
      }
    });

    if (analysis.nextButton?.detected || analysis.nextButton?.coordinates) {
      const nx = analysis.nextButton.coordinates?.xPercent;
      const ny = analysis.nextButton.coordinates?.yPercent;
      console.log(`[AutoSolve AI][COORDINATES] Next Button -> (${nx}%, ${ny}%)`);
      logEvent('COORDINATES', `Next Button located at coordinate (${nx}%, ${ny}%)`);
    }

    if (analysis.hasVideo) {
      logEvent('VIDEO', 'Video module detected: Activating 16x Video Controller...');
    }

    logEvent('ACTION', 'Dispatching target coordinates to page click simulator...');

    // Await the content script solution execution to avoid race conditions and stalling
    const contentResponse = await chrome.tabs.sendMessage(activeTab.id, {
      action: 'EXECUTE_SOLUTION',
      analysis,
      options,
    });

    logEvent('COMPLETE', `Execution complete: ${contentResponse?.clicksPerformed ?? 0} click(s) registered.`);
    return { success: true, analysis, contentResponse };
  } catch (error) {
    let msg = error.message;
    if (msg === 'Failed to fetch') {
      msg = 'Connection error. Please open the AutoSolve AI extension popup and paste your Gemini API key (AIzaSy...).';
    }
    logEvent('ERROR', `Auto-Solve failed: ${msg}`);
    return { success: false, error: msg };
  }
}