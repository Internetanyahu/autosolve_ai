import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import JSZip from 'jszip';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Support large screenshots in base64
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// CORS middleware so the Chrome extension can reach this server from any tab
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Initialize Gemini Client
const geminiApiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (geminiApiKey) {
  aiClient = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-memory log buffer for dashboard telemetry
interface LogEvent {
  id: string;
  timestamp: string;
  level: 'AI_VISION' | 'COORDINATES' | 'CLICK' | 'REASONING' | 'ERROR' | 'INFO' | 'VIDEO' | 'COMPLETE';
  message: string;
  data?: any;
}

const recentLogs: LogEvent[] = [
  {
    id: 'log-init',
    timestamp: new Date().toLocaleTimeString(),
    level: 'INFO',
    message: 'AutoSolve AI Server initialized and ready.',
    data: { geminiReady: !!geminiApiKey },
  },
];

function recordServerLog(level: LogEvent['level'], message: string, data?: any) {
  const item: LogEvent = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toLocaleTimeString(),
    level,
    message,
    data,
  };
  recentLogs.unshift(item);
  if (recentLogs.length > 200) recentLogs.pop();
  console.log(`[AutoSolve AI Server][${level}] ${message}`, data ? JSON.stringify(data).slice(0, 100) : '');
}

// Helper: normalize coordinates to 0-100 range
function normalizePercent(val: any, fallback = 50): number {
  if (typeof val === 'string') {
    const parsed = parseFloat(val.replace(/[^0-9.-]/g, ''));
    if (!isNaN(parsed)) val = parsed;
  }
  if (typeof val !== 'number' || isNaN(val)) return fallback;
  if (val > 0 && val <= 1) return Math.round(val * 1000) / 10; // normalized 0-1
  if (val > 100) return Math.min(100, Math.max(0, Math.round((val / 1000) * 1000) / 10)); // normalized 0-1000
  return Math.min(100, Math.max(0, Math.round(val * 10) / 10));
}

// API Routes

// 1. Health & Status
app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    status: 'online',
    name: 'AutoSolve AI Backend',
    geminiReady: !!aiClient,
    model: 'gemini-3.8-flash',
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    appUrl: process.env.APP_URL || `http://localhost:${PORT}`,
  });
});

// 2. Telemetry logs
app.get('/api/logs', (req: Request, res: Response) => {
  res.json({
    success: true,
    logs: recentLogs,
  });
});

// 3. Post a log from client/content-script
app.post('/api/logs', (req: Request, res: Response) => {
  const { level, message, data } = req.body;
  if (message) {
    recordServerLog(level || 'INFO', message, data);
  }
  res.json({ success: true });
});

// 4. Clear logs
app.post('/api/logs/clear', (req: Request, res: Response) => {
  recentLogs.length = 0;
  recordServerLog('INFO', 'Logs cleared by user.');
  res.json({ success: true });
});

// 5. Vision Q&A Screen Analyzer
app.post('/api/analyze-screen', async (req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const { imageBase64, viewportWidth = 1280, viewportHeight = 720, userPrompt = '' } = req.body;

    if (!imageBase64) {
      recordServerLog('ERROR', 'No imageBase64 provided in analyze-screen request.');
      return res.status(400).json({ success: false, error: 'imageBase64 payload is required.' });
    }

    if (!aiClient) {
      recordServerLog('ERROR', 'GEMINI_API_KEY environment variable is not configured.');
      return res.status(500).json({
        success: false,
        error: 'Gemini API is not configured on this server. Please attach an API key in the Secrets panel.',
      });
    }

    recordServerLog('AI_VISION', `Analyzing screenshot (${viewportWidth}x${viewportHeight}px)...`);

    // Clean base64 data URL
    let mimeType = 'image/png';
    let base64Data = imageBase64;
    const match = imageBase64.match(/^data:([^;]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      base64Data = match[2];
    } else if (imageBase64.startsWith('data:image/svg+xml')) {
      mimeType = 'image/svg+xml';
    }

    const systemPrompt = `You are an elite academic master and expert in English literature, specifically high school and AP English, specializing in Edgenuity English 4 A and English 4 B (British Literature, Romanticism, Victorian, Renaissance, Poetic Forms, Literary Analysis, Rhetoric, and Reading Comprehension).

1. EXPERTISE IN ENGLISH 4 A & ENGLISH 4 B:
   - You have encyclopedic mastery of British and World Literature across all eras:
     * Anglo-Saxon & Medieval (Beowulf, Chaucer/Canterbury Tales, Arthurian legends)
     * Renaissance & Shakespeare (Macbeth, Hamlet, Sonnets, metaphysical poets like Donne)
     * Enlightenment, Restoration, & Satire (Swift, Pope)
     * Romanticism (Keats, Wordsworth, Coleridge, Byron, Shelley, Blake)
     * Victorian Era (Tennyson, the Brownings, Bronte sisters, Dickens)
     * Modern & Postmodern Literature (Yeats, Eliot, Orwell, Woolf)
   - LITERARY FORMS & DEFINITIONS:
     * ODE: An exalted, formal lyric poem of serious reflection that pays homage to or addresses a person, object, or abstract concept (apostrophe, e.g. Keats's "Ode on a Grecian Urn" directly addressing the urn: "Thou, silent form...").
       - Distinctive features:
         (1) Written in a formal, elevated style with dignified diction and tone.
         (2) Directly addresses an object, person, or abstraction (apostrophe).
       - An ode does NOT tell a story (narrative poems and ballads tell stories; an ode is lyric and meditative).
       - An ode does NOT incorporate jokes or humor.
       - Generic poetic traits like using rhyme or stanzas are common to all traditional poetry and do NOT uniquely indicate that a poem is an ode.
     * BALLAD: A narrative poem meant to be sung or recited, typically telling a dramatic or tragic folk story in quatrains.
     * ELEGY: A solemn, reflective poem of mourning or lament for the dead.
     * EPIC: A long narrative poem recounting the deeds of a legendary or heroic figure.
     * SONNET: A 14-line poem with specific meter (iambic pentameter) and rhyme scheme (Petrarchan or Shakespearean).
   - MULTI-SELECT INSTRUCTIONS:
     * Always carefully check directives such as "Choose two correct answers", "Select two", "Choose all that apply", or "Select three".
     * Ensure EXACTLY the requested number of correct choices are flagged with "isCorrect": true.
     * Scrutinize every option individually. Never guess; prove each answer with evidence and literary definitions.

2. CRITICAL COORDINATE INSTRUCTION - CLICK THE CENTER OF THE TEXTBOX:
   - For every answer choice, coordinates MUST target the horizontal and vertical CENTER of the text box / choice container (the text block itself).
   - In modern educational platforms (including Edgenuity, Canvas, Blackboard, Schoology), the ENTIRE text box and option container is clickable.
   - DO NOT target the edge, corner, or the tiny checkbox/radio circle icon on the far left!
   - Target the middle of the option's text block (typically xPercent is between 30% and 55% across the screen depending on layout, and yPercent is directly at the vertical center of that option row).
   - Clicking the center of the text box is vastly more reliable, human-like, and robust.

3. SPECIALIZED SUPPORT FOR DROP-DOWN MENU QUESTIONS:
   - In Edgenuity English 4 A & B, many questions feature drop-down menus (<select> elements or clickable select boxes) positioned underneath sub-questions or sentences.
   - For drop-down questions:
     * Set "questionType": "dropdown".
     * Populate "dropdowns" array with an object for EACH drop-down menu on screen:
       - "prompt": The sub-question or context phrase above the dropdown (e.g. "What does the repetition of the phrase for ever suggest about the image on the vase?").
       - "selectedAnswer": The academically correct answer to choose in that drop-down menu.
       - "coordinates": { "xPercent", "yPercent" } pointing directly to the CENTER of the drop-down box/button on screen.
     * Also include corresponding entries in "options" with "isCorrect": true so both access formats are supported.
   - SPECIFIC KEATS "ODE ON A GRECIAN URN" (STANZA 3) DROP-DOWN RULES:
     * Question 1 ("What does the repetition of the phrase for ever suggest about the image on the vase?"):
       - Correct answer: The image is permanent / frozen in time / immortal (art never dies or fades, unlike mortal humans). DO NOT pick "The image is hard to see."
     * Question 2 ("What does the repetition of the word happy suggest?"):
       - Correct answer: The speaker admires the couple's joy / celebrates the eternal happiness of the scene.
     * Question 3 ("Based on the poet's diction, what is the tone of the passage?"):
       - Correct answer: admiring and joyful / celebratory / enthusiastic / reverent (Keats celebrates "happy, happy love!" and "unwearied" piping; it is definitely NOT "angry and bitter").

4. STRUCTURED DATA SPECIFICATION:
   - "question": The overall question text or prompt.
   - "questionType": "single_choice", "multiple_choice", "dropdown", "true_false", "text", or "video_only".
   - "conciseReasoning": Deep, precise academic explanation of why each correct option or dropdown value is right.
   - "hasVideo": true if an HTML5 or embedded lecture video is the focal content.
   - "options": An array of each selectable answer or choice.
     - "text": The textual label of the choice.
     - "isCorrect": true if this is the correct answer according to academic/domain accuracy.
     - "confidence": confidence from 0.0 to 1.0.
     - "coordinates": { "xPercent": X percentage (0 to 100) of the horizontal CENTER of the choice text box, "yPercent": Y percentage (0 to 100) of the vertical center of the text box }.
   - "dropdowns": An array of drop-down menus (if questionType is "dropdown"):
     - "prompt": The question or label for this dropdown.
     - "selectedAnswer": The exact text of the correct option to select.
     - "coordinates": { "xPercent", "yPercent" } of the center of the drop-down box.
   - "nextButton":
     - "detected": true if a "Next", "Submit", "Continue", or "Proceed" button is visible.
     - "coordinates": { "xPercent": X percentage (0 to 100) of the center of this button, "yPercent": Y percentage (0 to 100) }.`;

    const userText = userPrompt
      ? `User hint/instruction: "${userPrompt}". Analyze the screen and provide correct answers and exact clickable coordinates.`
      : 'Analyze this screen as an expert in English 4 A & B. Detect the question, choices with exact clickable coordinates pointing to the center of each text box (xPercent, yPercent), identify the academically correct answer(s), handle any drop-down menus, and locate the Next/Submit button.';

    let geminiContents: any;
    if (mimeType === 'image/svg+xml') {
      // Decode SVG and extract plain text structure for Gemini
      const decodedSvg = decodeURIComponent(imageBase64.replace(/^data:image\/svg\+xml;utf8,/, ''));
      const textMatches = Array.from(decodedSvg.matchAll(/<text[^>]*>([^<]+)<\/text>/g)).map(m => m[1]);
      geminiContents = {
        parts: [
          {
            text: `This is the textual representation of the quiz screen:\n${textMatches.join('\n')}\n\n${userText}`,
          },
        ],
      };
    } else {
      geminiContents = {
        parts: [
          {
            inlineData: {
              mimeType,
              data: base64Data,
            },
          },
          {
            text: userText,
          },
        ],
      };
    }

    const modelConfig = {
      systemInstruction: systemPrompt,
      thinkingConfig: {
        thinkingLevel: ThinkingLevel.HIGH, // Thorough academic reasoning for literature and multi-select prompts
      },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
          questionType: { type: Type.STRING },
          conciseReasoning: { type: Type.STRING },
          hasVideo: { type: Type.BOOLEAN },
          options: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                isCorrect: { type: Type.BOOLEAN },
                confidence: { type: Type.NUMBER },
                coordinates: {
                  type: Type.OBJECT,
                  properties: {
                    xPercent: { type: Type.NUMBER },
                    yPercent: { type: Type.NUMBER },
                  },
                  required: ['xPercent', 'yPercent'],
                },
              },
              required: ['text', 'isCorrect', 'coordinates'],
            },
          },
          dropdowns: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                prompt: { type: Type.STRING },
                selectedAnswer: { type: Type.STRING },
                coordinates: {
                  type: Type.OBJECT,
                  properties: {
                    xPercent: { type: Type.NUMBER },
                    yPercent: { type: Type.NUMBER },
                  },
                  required: ['xPercent', 'yPercent'],
                },
              },
              required: ['prompt', 'selectedAnswer', 'coordinates'],
            },
          },
          nextButton: {
            type: Type.OBJECT,
            properties: {
              detected: { type: Type.BOOLEAN },
              coordinates: {
                type: Type.OBJECT,
                properties: {
                  xPercent: { type: Type.NUMBER },
                  yPercent: { type: Type.NUMBER },
                },
              },
            },
          },
        },
        required: ['question', 'questionType', 'conciseReasoning', 'options'],
      },
    };

    let response: any;
    let usedModel = 'gemini-3.8-flash';
    try {
      response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: geminiContents,
        config: modelConfig,
      });
    } catch (primaryErr: any) {
      recordServerLog('INFO', `Primary model gemini-3.8-flash unavailable (${primaryErr.status || primaryErr.message}). Retrying with gemini-flash-latest...`);
      usedModel = 'gemini-flash-latest';
      response = await aiClient.models.generateContent({
        model: 'gemini-flash-latest',
        contents: geminiContents,
        config: modelConfig,
      });
    }

    const rawText = response.text || '{}';
    let analysis: any = {};
    try {
      analysis = JSON.parse(rawText);
    } catch (parseErr) {
      recordServerLog('ERROR', `Failed to parse Gemini JSON: ${rawText.slice(0, 150)}`);
      throw new Error('Gemini returned invalid JSON structure.');
    }

    // Sanitize coordinates and normalize
    if (Array.isArray(analysis.options)) {
      analysis.options = analysis.options.map((opt: any, index: number) => {
        const rawCoords = opt.coordinates || {};
        const xPct = normalizePercent(rawCoords.xPercent ?? rawCoords.x, 30);
        const yPct = normalizePercent(rawCoords.yPercent ?? rawCoords.y, 40 + index * 10);
        return {
          text: String(opt.text || `Option ${index + 1}`),
          isCorrect: Boolean(opt.isCorrect),
          confidence: typeof opt.confidence === 'number' ? opt.confidence : 0.95,
          coordinates: {
            xPercent: xPct,
            yPercent: yPct,
          },
        };
      });
    } else {
      analysis.options = [];
    }

    // Sanitize dropdown coordinates and normalize
    if (Array.isArray(analysis.dropdowns)) {
      analysis.dropdowns = analysis.dropdowns.map((dd: any, index: number) => {
        const rawCoords = dd.coordinates || {};
        const xPct = normalizePercent(rawCoords.xPercent ?? rawCoords.x, 50);
        const yPct = normalizePercent(rawCoords.yPercent ?? rawCoords.y, 30 + index * 15);
        return {
          prompt: String(dd.prompt || `Dropdown ${index + 1}`),
          selectedAnswer: String(dd.selectedAnswer || ''),
          coordinates: {
            xPercent: xPct,
            yPercent: yPct,
          },
        };
      });
    } else {
      analysis.dropdowns = [];
    }

    // Sanitize next button coordinates
    if (analysis.nextButton) {
      const nb = analysis.nextButton;
      const nbX = normalizePercent(nb.coordinates?.xPercent ?? nb.coordinates?.x, 88);
      const nbY = normalizePercent(nb.coordinates?.yPercent ?? nb.coordinates?.y, 88);
      analysis.nextButton = {
        detected: Boolean(nb.detected ?? true),
        coordinates: {
          xPercent: nbX,
          yPercent: nbY,
        },
      };
    }

    const duration = Date.now() - startTime;
    recordServerLog('AI_VISION', `Gemini finished in ${duration}ms. Question: "${analysis.question?.slice(0, 60)}..."`);
    recordServerLog('REASONING', analysis.conciseReasoning || 'N/A');

    // Note retrieved answers and coordinates in the server log
    analysis.options.forEach((opt: any, idx: number) => {
      const isAns = opt.isCorrect;
      const xPct = opt.coordinates.xPercent;
      const yPct = opt.coordinates.yPercent;
      const xPx = Math.round((xPct / 100) * viewportWidth);
      const yPx = Math.round((yPct / 100) * viewportHeight);
      recordServerLog(
        'COORDINATES',
        `Option ${idx + 1} [${isAns ? 'CORRECT' : 'INCORRECT'}]: "${opt.text}" -> X=${xPx}px (${xPct}%), Y=${yPx}px (${yPct}%)`,
        { isCorrect: isAns, xPercent: xPct, yPercent: yPct, xPx, yPx }
      );
    });

    if (analysis.dropdowns && analysis.dropdowns.length > 0) {
      analysis.dropdowns.forEach((dd: any, idx: number) => {
        const xPct = dd.coordinates.xPercent;
        const yPct = dd.coordinates.yPercent;
        const xPx = Math.round((xPct / 100) * viewportWidth);
        const yPx = Math.round((yPct / 100) * viewportHeight);
        recordServerLog(
          'COORDINATES',
          `Dropdown ${idx + 1} [Prompt: "${dd.prompt.slice(0, 30)}..."]: Select -> "${dd.selectedAnswer}" at X=${xPx}px (${xPct}%), Y=${yPx}px (${yPct}%)`,
          { dropdownIndex: idx, selectedAnswer: dd.selectedAnswer, xPercent: xPct, yPercent: yPct, xPx, yPx }
        );
      });
    }

    if (analysis.nextButton?.detected) {
      const nxPct = analysis.nextButton.coordinates.xPercent;
      const nyPct = analysis.nextButton.coordinates.yPercent;
      const nxPx = Math.round((nxPct / 100) * viewportWidth);
      const nyPx = Math.round((nyPct / 100) * viewportHeight);
      recordServerLog('COORDINATES', `Next Button located -> X=${nxPx}px (${nxPct}%), Y=${nyPx}px (${nyPct}%)`, {
        xPercent: nxPct,
        yPercent: nyPct,
        xPx: nxPx,
        yPx: nyPx,
      });
    }

    res.json({
      success: true,
      analysis,
      meta: {
        latencyMs: duration,
        model: usedModel,
        viewport: { width: viewportWidth, height: viewportHeight },
      },
    });
  } catch (err: any) {
    const duration = Date.now() - startTime;
    recordServerLog('ERROR', `Analyze failed after ${duration}ms: ${err.message}`);
    res.status(500).json({
      success: false,
      error: err.message || 'Screen analysis failed.',
    });
  }
});

// 6. Dynamic Chrome Extension ZIP Builder & Downloader
app.get('/api/download-extension', async (req: Request, res: Response) => {
  try {
    const requestedServerUrl = (req.query.serverUrl as string) || process.env.APP_URL || `http://localhost:${PORT}`;
    const cleanUrl = requestedServerUrl.replace(/\/+$/, '');

    const extDir = path.resolve(process.cwd(), 'extension');
    if (!fs.existsSync(extDir)) {
      return res.status(404).json({ error: 'Extension directory not found on server.' });
    }

    const zip = new JSZip();

    function addDirToZip(dir: string, zipFolder: JSZip) {
      const items = fs.readdirSync(dir);
      for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          addDirToZip(fullPath, zipFolder.folder(item)!);
        } else {
          let content = fs.readFileSync(fullPath);
          // If background.js, inject default server URL
          if (item === 'background.js') {
            let str = content.toString('utf-8');
            str = str.replace(/const DEFAULT_SERVER_URL = '[^']*';/, `const DEFAULT_SERVER_URL = '${cleanUrl}';`);
            content = Buffer.from(str, 'utf-8');
          }
          zipFolder.file(item, content);
        }
      }
    }

    addDirToZip(extDir, zip);

    const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="autosolve-ai-chrome-extension.zip"');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err: any) {
    res.status(500).json({ error: `Failed to create extension zip: ${err.message}` });
  }
});

// 7. Get raw extension files for direct in-browser inspection and copying
app.get('/api/extension/files', (req: Request, res: Response) => {
  try {
    const extDir = path.resolve(process.cwd(), 'extension');
    const result: Record<string, string> = {};

    function readFilesRecursively(dir: string, prefix = '') {
      const items = fs.readdirSync(dir);
      for (const item of items) {
        const fullPath = path.join(dir, item);
        const relPath = prefix ? `${prefix}/${item}` : item;
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          readFilesRecursively(fullPath, relPath);
        } else if (item.endsWith('.png')) {
          result[relPath] = `data:image/png;base64,${fs.readFileSync(fullPath).toString('base64')}`;
        } else {
          result[relPath] = fs.readFileSync(fullPath, 'utf-8');
        }
      }
    }

    readFilesRecursively(extDir);
    res.json({ success: true, files: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Setup Vite middleware for full-stack SPA
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AutoSolve AI] Server listening on port ${PORT}`);
    console.log(`[AutoSolve AI] Gemini integration: ${aiClient ? 'READY' : 'NO API KEY'}`);
  });
}

startServer();
