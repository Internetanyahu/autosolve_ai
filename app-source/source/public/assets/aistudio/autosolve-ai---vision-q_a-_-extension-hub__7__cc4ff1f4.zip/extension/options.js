document.addEventListener('DOMContentLoaded', () => {
  const keyInput = document.getElementById('geminiApiKey');
  const speedInput = document.getElementById('videoSpeed');
  const waitInput = document.getElementById('videoWaitSeconds');
  const saveBtn = document.getElementById('save-btn');
  const testBtn = document.getElementById('test-btn');
  const statusMsg = document.getElementById('status-msg');

  function showStatus(text, isError = false) {
    statusMsg.textContent = text;
    statusMsg.className = isError ? 'status-error' : 'status-success';
    statusMsg.style.display = 'block';
  }

  chrome.storage.sync.get(
    { geminiApiKey: '', videoSpeed: 16, videoWaitSeconds: 15 },
    (data) => {
      keyInput.value = data.geminiApiKey || '';
      speedInput.value = data.videoSpeed || 16;
      waitInput.value = data.videoWaitSeconds || 15;
    }
  );

  saveBtn.onclick = () => {
    const rawKey = keyInput.value.trim();
    const payload = {
      geminiApiKey: rawKey,
      videoSpeed: Math.min(16, Math.max(1, Number(speedInput.value) || 16)),
      videoWaitSeconds: Math.max(3, Number(waitInput.value) || 15),
    };

    chrome.storage.sync.set(payload, () => {
      showStatus('Settings saved successfully!');
      setTimeout(() => {
        statusMsg.style.display = 'none';
      }, 3000);
    });
  };

  testBtn.onclick = async () => {
    const key = keyInput.value.trim();
    if (!key) {
      showStatus('Please enter a Gemini API key first.', true);
      return;
    }

    showStatus('Verifying key with Google Gemini API...');

    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${key}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: 'ping' }] }] }),
      });

      if (res.ok) {
        showStatus('Key Verified! Connected to Google Gemini API.');
      } else {
        const errJson = await res.json().catch(() => ({}));
        showStatus(`Verification failed: ${errJson.error?.message || `HTTP ${res.status}`}`, true);
      }
    } catch (err) {
      showStatus(`Network connection failed: ${err.message}`, true);
    }
  };
});