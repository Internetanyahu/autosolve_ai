document.addEventListener('DOMContentLoaded', async () => {
  const btnScan = document.getElementById('btn-scan');
  const btnAutopilot = document.getElementById('btn-autopilot');
  const btnVideo = document.getElementById('btn-video');
  const btnClear = document.getElementById('btn-clear');
  const btnOptions = document.getElementById('btn-options');
  const chkAutoNext = document.getElementById('chk-auto-next');
  const consoleBox = document.getElementById('console-box');
  const statusBadge = document.getElementById('api-status');
  const inputApiKey = document.getElementById('input-api-key');
  const btnSaveKey = document.getElementById('btn-save-key');
  const btnToggleKey = document.getElementById('btn-toggle-key');
  const keyHint = document.getElementById('key-hint');

  const btnManualNext = document.getElementById('btn-manual-next');

  let isAutoPilotActive = false;

  function appendLog(level, msg) {
    const d = document.createElement('div');
    d.className = `log-item log-${level || 'INFO'}`;
    const time = new Date().toLocaleTimeString();
    d.textContent = `[${time}] ${msg}`;
    consoleBox.appendChild(d);
    consoleBox.scrollTop = consoleBox.scrollHeight;
  }

  if (btnManualNext) {
    btnManualNext.onclick = () => {
      appendLog('ACTION', 'Advancing to next activity (.FrameRight)...');
      chrome.runtime.sendMessage({ action: 'TRIGGER_MANUAL_NEXT' }, (res) => {
        if (res && res.success) {
          appendLog('CLICK', 'Next / Submit clicked successfully across all frames!');
        } else {
          appendLog('ACTION', 'Attempted Next button click across all frames.');
        }
      });
    };
  }

  btnClear.onclick = () => {
    consoleBox.innerHTML = '';
  };

  btnOptions.onclick = () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options.html'));
    }
  };

  btnToggleKey.onclick = () => {
    if (inputApiKey.type === 'password') {
      inputApiKey.type = 'text';
      btnToggleKey.textContent = 'Hide';
    } else {
      inputApiKey.type = 'password';
      btnToggleKey.textContent = 'Show';
    }
  };

  // Verify Gemini API key by making a lightweight test call
  async function testGeminiApiKey(key) {
    if (!key || key.length < 15) {
      statusBadge.innerHTML = `<span style="color:#ef4444;">● Paste API Key</span>`;
      keyHint.textContent = 'Key needed (AIzaSy...)';
      keyHint.style.color = '#f87171';
      return false;
    }

    statusBadge.innerHTML = `<span style="color:#eab308;">Testing Key...</span>`;
    try {
      const pingStart = Date.now();
      const testUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${key}`;
      const res = await fetch(testUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: 'ping' }] }],
        }),
      });

      const latency = Date.now() - pingStart;

      if (res.ok) {
        statusBadge.innerHTML = `<span style="color:#10b981;">● Key Active (${latency}ms)</span>`;
        keyHint.textContent = 'Key verified with Google';
        keyHint.style.color = '#34d399';
        appendLog('INFO', `Gemini API key verified successfully (${latency}ms latency)`);
        return true;
      } else {
        const errJson = await res.json().catch(() => ({}));
        const errMsg = errJson.error?.message || `HTTP ${res.status}`;
        statusBadge.innerHTML = `<span style="color:#ef4444;">● Invalid Key</span>`;
        keyHint.textContent = errMsg.slice(0, 30);
        keyHint.style.color = '#f87171';
        appendLog('ERROR', `Gemini API key error: ${errMsg}`);
        return false;
      }
    } catch (err) {
      statusBadge.innerHTML = `<span style="color:#ef4444;">● Network Error</span>`;
      keyHint.textContent = 'Check internet';
      appendLog('ERROR', `Connection failed: ${err.message}`);
      return false;
    }
  }

  // Load saved API key from chrome.storage.sync
  chrome.storage.sync.get(['geminiApiKey'], (res) => {
    if (res.geminiApiKey) {
      inputApiKey.value = res.geminiApiKey;
      testGeminiApiKey(res.geminiApiKey);
    } else {
      statusBadge.innerHTML = `<span style="color:#ef4444;">● Paste API Key</span>`;
    }
  });

  // Save new API Key
  btnSaveKey.onclick = () => {
    const rawKey = inputApiKey.value.trim();
    if (!rawKey) {
      chrome.storage.sync.remove(['geminiApiKey'], () => {
        statusBadge.innerHTML = `<span style="color:#ef4444;">● No Key</span>`;
        appendLog('INFO', 'API key removed.');
      });
      return;
    }

    btnSaveKey.disabled = true;
    btnSaveKey.textContent = 'Verifying...';

    testGeminiApiKey(rawKey).then((valid) => {
      btnSaveKey.disabled = false;
      btnSaveKey.textContent = 'Save Key';

      chrome.storage.sync.set({ geminiApiKey: rawKey }, () => {
        if (valid) {
          appendLog('INFO', 'Gemini API key saved! Ready to solve tabs.');
        } else {
          appendLog('ERROR', 'Key saved, but Google reported an authentication error.');
        }
      });
    });
  };

  function updateAutopilotButton(running) {
    if (running) {
      btnAutopilot.textContent = 'Stop Auto-Pilot';
      btnAutopilot.classList.add('running');
    } else {
      btnAutopilot.textContent = 'Start Auto-Pilot';
      btnAutopilot.classList.remove('running');
    }
  }

  btnScan.onclick = () => {
    appendLog('ACTION', 'Initiating screen capture & Gemini analysis...');
    btnScan.disabled = true;
    btnScan.textContent = 'Analyzing with Gemini...';

    chrome.runtime.sendMessage(
      {
        action: 'TRIGGER_SCAN',
        options: { autoClickNext: chkAutoNext.checked },
      },
      (response) => {
        btnScan.disabled = false;
        btnScan.textContent = 'Scan & Solve Active Tab';
        if (response && response.success) {
          appendLog('COMPLETE', 'Auto-solve completed successfully.');
        } else if (response && response.error) {
          appendLog('ERROR', `Error: ${response.error}`);
        }
      }
    );
  };

  btnAutopilot.onclick = () => {
    if (isAutoPilotActive) {
      chrome.runtime.sendMessage({ action: 'STOP_AUTOPILOT' }, () => {
        isAutoPilotActive = false;
        updateAutopilotButton(false);
        appendLog('ACTION', 'Auto-Pilot deactivated.');
      });
    } else {
      chrome.runtime.sendMessage({ action: 'START_AUTOPILOT' }, () => {
        isAutoPilotActive = true;
        updateAutopilotButton(true);
        appendLog('ACTION', 'Auto-Pilot activated! Loop will run continuously.');
      });
    }
  };

  btnVideo.onclick = () => {
    appendLog('VIDEO', 'Accelerating videos in active tab to 16x...');
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'BOOST_VIDEO_16X' }, (res) => {
          if (res?.success) appendLog('VIDEO', 'Videos accelerated to 16x with 15s timer.');
        });
      }
    });
  };

  chrome.runtime.onMessage.addListener((req) => {
    if (req.action === 'NEW_LOG' && req.log) {
      appendLog(req.log.level, req.log.message);
    }
  });

  // Query background status
  chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (res) => {
    isAutoPilotActive = !!res?.isAutoPilotRunning;
    updateAutopilotButton(isAutoPilotActive);
  });
});